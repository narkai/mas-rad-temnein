-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 18 Décembre 2013 à 01:52
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `temnein`
--

-- --------------------------------------------------------

--
-- Structure de la table `tomes`
--

CREATE TABLE `tomes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `text` text NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

--
-- Contenu de la table `tomes`
--

INSERT INTO `tomes` (`id`, `date`, `text`, `user_id`) VALUES(97, '2013-12-18 01:51:22', 'Hello, my name is Matthieu.', 4);
INSERT INTO `tomes` (`id`, `date`, `text`, `user_id`) VALUES(98, '2013-12-18 01:51:39', 'I like blue.', 4);
INSERT INTO `tomes` (`id`, `date`, `text`, `user_id`) VALUES(99, '2013-12-18 01:52:02', 'Hello, I am Karian.', 3);
INSERT INTO `tomes` (`id`, `date`, `text`, `user_id`) VALUES(100, '2013-12-18 01:52:10', 'I like green.', 3);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `pass_md5` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `username`, `pass_md5`) VALUES(3, 'karian', '1a1dc91c907325c69271ddf0c944bc72');
INSERT INTO `users` (`id`, `username`, `pass_md5`) VALUES(4, 'matthieu', '1a1dc91c907325c69271ddf0c944bc72');
